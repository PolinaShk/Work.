import requests
import base64
from datetime import datetime, timedelta
import pytz
from bot.utils import decrypt_caldav_password
import re
import logging

logger = logging.getLogger(__name__)

PROJECT_EMAIL = "mailbot@id-east.ru"

class CalDAVService:
    def __init__(self, url, username, encrypted_password):
        self.base_url = url.rstrip("/")
        self.ics_url = self.base_url + ".ics"
        self.username = username
        self.password = decrypt_caldav_password(encrypted_password)
        self.session = requests.Session()
        auth = base64.b64encode(f"{self.username}:{self.password}".encode()).decode()
        self.session.headers.update({
            "Authorization": f"Basic {auth}",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Accept": "text/calendar"
        })
        self.msk = pytz.timezone("Europe/Moscow")

    def get_events(self, start: datetime, end: datetime, timeout: int = 15):
        try:
            start_utc = start.astimezone(pytz.UTC) if start.tzinfo else pytz.UTC.localize(start)
            end_utc = end.astimezone(pytz.UTC) if end.tzinfo else pytz.UTC.localize(end)
            
            resp = self.session.get(self.ics_url, timeout=timeout)
            if resp.status_code == 401:
                raise Exception("401: Неверный логин или пароль")
            if resp.status_code == 404:
                raise Exception("404: Календарь не найден")
            if resp.status_code == 403:
                raise Exception("403: Доступ запрещён")
            if resp.status_code != 200:
                raise Exception(f"Ошибка сервера: {resp.status_code}")
            
            content = self._normalize_ics_content(resp.text)
            events = self._parse_ics(content, start_utc, end_utc)
            
            for event in events:
                if event["start"].tzinfo:
                    event["start"] = event["start"].astimezone(self.msk)
                if event["end"].tzinfo:
                    event["end"] = event["end"].astimezone(self.msk)
            
            return events
        except Exception as e:
            logger.error(f"get_events error: {e}")
            raise

    def _normalize_ics_content(self, content):
        content = content.replace('\r\n', '\n').replace('\r', '\n')
        content = content.replace("&lt;", "<").replace("&gt;", ">")
        content = content.replace("&amp;", "&").replace("&quot;", '"')
        content = content.replace("&#39;", "'")
        lines = content.split("\n")
        normalized = []
        for line in lines:
            if line.startswith(" ") and normalized:
                normalized[-1] += line.strip()
            else:
                normalized.append(line)
        return "\n".join(normalized)

    def _parse_ics(self, content, start, end):
        events = []
        seen_keys = set()
        pattern = r'BEGIN:VEVENT\s*(.*?)\s*END:VEVENT'
        matches = re.findall(pattern, content, re.DOTALL | re.IGNORECASE)
        
        for block in matches:
            event = self._parse_vevent(block)
            if not event:
                continue
            evt_start = event.get("start")
            evt_end = event.get("end")
            if not evt_start or not evt_end:
                continue
            
            if evt_start.tzinfo:
                evt_start_utc = evt_start.astimezone(pytz.UTC)
            else:
                evt_start_utc = pytz.UTC.localize(evt_start)
            if evt_end.tzinfo:
                evt_end_utc = evt_end.astimezone(pytz.UTC)
            else:
                evt_end_utc = pytz.UTC.localize(evt_end)
            
            rrule = event.get("rrule")
            if rrule and False:
                try:
                    recurring = self._expand_rrule(event, start, end)
                    for rec in recurring:
                        key = f"{rec.get('uid', rec['summary'])}_{rec['start']}"
                        if key not in seen_keys:
                            seen_keys.add(key)
                            events.append(rec)
                except:
                    continue
            else:
                if evt_start_utc < end and evt_end_utc > start:
                    key = f"{event.get('uid', event['summary'])}_{evt_start}"
                    if key not in seen_keys:
                        seen_keys.add(key)
                        events.append(event)
        
        events.sort(key=lambda x: x['start'])
        return events

    def _parse_vevent(self, block):
        event = {
            "summary": "Без названия",
            "start": None,
            "end": None,
            "location": "",
            "description": "",
            "attendees": [],
            "rrule": None,
            "uid": None,
            "organizer": None
        }
        lines = block.split("\n")
        for line in lines:
            line = line.strip()
            if not line:
                continue
            if line.startswith("SUMMARY"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    event["summary"] = parts[1].strip()
            elif line.startswith("DTSTART"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    event["start"] = self._parse_date(parts[1].strip(), line)
            elif line.startswith("DTEND"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    event["end"] = self._parse_date(parts[1].strip(), line)
            elif line.startswith("LOCATION"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    event["location"] = parts[1].strip()
            elif line.startswith("DESCRIPTION"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    event["description"] = parts[1].strip()
            elif line.startswith("RRULE"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    event["rrule"] = parts[1].strip()
            elif line.startswith("ATTENDEE"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    attendee = parts[1].strip().replace("mailto:", "")
                    if attendee and attendee not in event["attendees"]:
                        event["attendees"].append(attendee)
            elif line.startswith("ORGANIZER"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    event["organizer"] = parts[1].strip().replace("mailto:", "")
            elif line.startswith("UID"):
                parts = line.split(":", 1)
                if len(parts) > 1:
                    event["uid"] = parts[1].strip()
        if event["start"] and not event["end"]:
            event["end"] = event["start"] + timedelta(hours=1)
        return event if event["start"] and event["end"] else None

    def _parse_date(self, date_str, full_line=""):
        date_str = date_str.strip()
        if ";TZID=" in full_line:
            tz_match = re.search(r'TZID=([^:]+)', full_line)
            if tz_match and ":" in full_line:
                date_part = full_line.split(":", 1)[1].strip()
                if re.match(r'^\d{8}T\d{6}$', date_part):
                    try:
                        dt = datetime.strptime(date_part, "%Y%m%dT%H%M%S")
                        tz_name = tz_match.group(1)
                        tz = pytz.timezone(tz_name)
                        return tz.localize(dt)
                    except:
                        pass
        if re.match(r'^\d{8}T\d{6}Z$', date_str):
            try:
                dt = datetime.strptime(date_str, "%Y%m%dT%H%M%SZ")
                return dt.replace(tzinfo=pytz.UTC)
            except:
                pass
        utc_offset_match = re.match(r'^(\d{8}T\d{6})([+-]\d{2})(\d{2})$', date_str)
        if utc_offset_match:
            try:
                dt_str, offset_h, offset_m = utc_offset_match.groups()
                dt = datetime.strptime(dt_str, "%Y%m%dT%H%M%S")
                offset_hours = int(offset_h)
                offset_mins = int(offset_m)
                if date_str.find('+') != -1:
                    dt = dt - timedelta(hours=offset_hours, minutes=offset_mins)
                else:
                    dt = dt + timedelta(hours=offset_hours, minutes=offset_mins)
                return dt.replace(tzinfo=pytz.UTC)
            except:
                pass
        if re.match(r'^\d{8}T\d{6}$', date_str):
            try:
                dt = datetime.strptime(date_str, "%Y%m%dT%H%M%S")
                return self.msk.localize(dt)
            except:
                pass
        if re.match(r'^\d{8}$', date_str):
            try:
                dt = datetime.strptime(date_str, "%Y%m%d")
                return self.msk.localize(dt)
            except:
                pass
        return None

    def _expand_rrule(self, event, range_start, range_end):
        return []

    def create_event(self, summary, start, end, location="", attendees=None, description=""):
        import time
        uid = f"{int(time.time())}_{abs(hash(summary))}@bot"
        
        if attendees is None:
            attendees = []
        
        # Всегда добавляем PROJECT_EMAIL и email автора
        final_attendees = set(attendees)
        final_attendees.add(PROJECT_EMAIL)
        if self.username:
            final_attendees.add(self.username)
        attendees = list(final_attendees)
        
        logger.info(f"create_event: отправка приглашений на email: {attendees}")
        
        attendee_str = ""
        for att in attendees:
            if att:
                attendee_str += f"ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=TRUE:mailto:{att}\n"
        
        organizer_str = f"ORGANIZER:mailto:{self.username}\n"
        
        if start.tzinfo:
            start_utc = start.astimezone(pytz.UTC)
        else:
            start_utc = self.msk.localize(start).astimezone(pytz.UTC)
        if end.tzinfo:
            end_utc = end.astimezone(pytz.UTC)
        else:
            end_utc = self.msk.localize(end).astimezone(pytz.UTC)
        
        start_str = start_utc.strftime('%Y%m%dT%H%M%SZ')
        end_str = end_utc.strftime('%Y%m%dT%H%M%SZ')
        now_str = datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
        summary = summary.replace('\\', '\\\\').replace(';', '\\;').replace(',', '\\,')
        location = location.replace('\\', '\\\\').replace(';', '\\;').replace(',', '\\,')
        description = description.replace('\\', '\\\\').replace(';', '\\;').replace(',', '\\,')
        
        ics = f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//TelegramBot//RU
CALSCALE:GREGORIAN
METHOD:REQUEST
BEGIN:VEVENT
UID:{uid}
DTSTAMP:{now_str}
DTSTART:{start_str}
DTEND:{end_str}
SUMMARY:{summary}
LOCATION:{location}
DESCRIPTION:{description}
{organizer_str}{attendee_str}STATUS:CONFIRMED
SEQUENCE:0
END:VEVENT
END:VCALENDAR"""
        
        filename = f"{uid}.ics"
        put_url = f"{self.base_url}/{filename}"
        try:
            resp = self.session.put(
                put_url,
                data=ics.encode("utf-8"),
                headers={
                    "Content-Type": "text/calendar; charset=utf-8",
                    "If-None-Match": "*"
                },
                timeout=30
            )
            if resp.status_code in [201, 204]:
                logger.info(f"create_event: успешно создано для {self.username}")
                return True, uid
            raise Exception(f"Ошибка создания ({resp.status_code})")
        except Exception as e:
            logger.error(f"create_event ошибка: {e}")
            raise


def send_email_invite(to_email, subject, body, html_body=None, ics_content=None):
    import smtplib
    from email.mime.text import MIMEText
    from email.mime.multipart import MIMEMultipart
    from bot.config import SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD
    
    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"] = SMTP_USER
        msg["To"] = to_email
        part1 = MIMEText(body, "plain", "utf-8")
        msg.attach(part1)
        if html_body:
            part2 = MIMEText(html_body, "html", "utf-8")
            msg.attach(part2)
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as server:
            server.starttls()
            server.login(SMTP_USER, SMTP_PASSWORD)
            server.send_message(msg)
        logger.info(f"Email отправлен на {to_email}")
        return True
    except Exception as e:
        logger.error(f"Email send error to {to_email}: {e}")
        return False


def test_caldav_connection(url, username, encrypted_password):
    try:
        service = CalDAVService(url, username, encrypted_password)
        tz = pytz.timezone("Europe/Moscow")
        now = datetime.now(tz)
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        service.get_events(start, end)
        return True, None
    except Exception as e:
        error_str = str(e)
        if "401" in error_str:
            return False, "Неверный пароль"
        elif "timeout" in error_str.lower():
            return False, "Таймаут подключения"
        else:
            return False, error_str[:100]