from datetime import datetime, timedelta
import pytz
from sqlalchemy import select
from bot.database import async_session, User, UserCalendar
from bot.services.caldav_service import CalDAVService

async def send_notifications(application):
    now = datetime.now(pytz.timezone("Europe/Moscow"))
    if now.hour != 8 or now.minute != 45:
        return
    if now.weekday() > 4:
        return
    async with async_session() as session:
        result = await session.execute(select(UserCalendar).join(User).where(User.is_approved == True, User.is_blocked == False))
        calendars = result.scalars().all()
        for cal in calendars:
            user_tz = pytz.timezone(cal.timezone)
            local_now = now.astimezone(user_tz)
            should_send = False
            events = []
            if cal.notification_daily and local_now.weekday() < 5:
                start = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
                end = start + timedelta(days=1)
                service = CalDAVService(cal.caldav_url, cal.caldav_username, cal.caldav_password_encrypted)
                try:
                    events = service.get_events(start, end)
                    should_send = True
                except:
                    pass
            if cal.notification_weekly and local_now.weekday() == 0:
                start = local_now.replace(hour=0, minute=0, second=0, microsecond=0)
                end = start + timedelta(days=7)
                service = CalDAVService(cal.caldav_url, cal.caldav_username, cal.caldav_password_encrypted)
                try:
                    week_events = [e for e in service.get_events(start, end) if e["start"] > local_now]
                    events.extend(week_events)
                    should_send = True
                except:
                    pass
            if should_send and events:
                msg = "Events:\n"
                for e in sorted(events, key=lambda x: x["start"]):
                    st = e["start"].astimezone(user_tz).strftime("%H:%M")
                    msg += st + " " + e["summary"] + "\n"
                try:
                    await application.bot.send_message(chat_id=cal.user_id, text=msg)
                except:
                    pass