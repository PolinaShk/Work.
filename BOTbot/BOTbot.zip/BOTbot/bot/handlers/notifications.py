from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from sqlalchemy import select
from bot.database import async_session, User, UserCalendar

async def check_access(user_id):
    async with async_session() as session:
        user = await session.get(User, user_id)
        return user and user.is_approved and not user.is_blocked

async def notification_settings(update, context):
    if not await check_access(update.effective_user.id):
        return
    async with async_session() as session:
        result = await session.execute(select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id))
        cal = result.scalars().first()
        if not cal:
            await update.message.reply_text("❌ Сначала добавьте календарь: /addcalendar")
            return
        d = "✅" if cal.notification_daily else "❌"
        w = "✅" if cal.notification_weekly else "❌"
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton(
                f"Ежедневно: {d}", callback_data="toggle_daily"
            )],
            [InlineKeyboardButton(
                f"Еженедельно: {w}", callback_data="toggle_weekly"
            )],
        ])
        
        await update.message.reply_text(
            "🔔 <b>Настройки уведомлений:</b>\n\n"
            "• Ежедневно (Пн-Пт в 8:45) — встречи на сегодня\n"
            "• Еженедельно (Пн в 8:45) — встречи на неделю\n\n"
            "Нажмите на кнопку, чтобы включить/выключить:",
            reply_markup=keyboard,
            parse_mode="HTML"
        )

async def toggle_daily(update, context):
    query = update.callback_query
    await query.answer()
    
    if not await check_access(update.effective_user.id):
        return
    async with async_session() as session:
        result = await session.execute(select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id))
        cal = result.scalars().first()
        if cal:
            cal.notification_daily = not cal.notification_daily
            await session.commit()
            s = "✅ включены" if cal.notification_daily else "❌ выключены"
            
            d = "✅" if cal.notification_daily else "❌"
            w = "✅" if cal.notification_weekly else "❌"
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(f"Ежедневно: {d}", callback_data="toggle_daily")],
                [InlineKeyboardButton(f"Еженедельно: {w}", callback_data="toggle_weekly")],
            ])
            await query.edit_message_text(
                f"🔔 <b>Настройки уведомлений:</b>\n\n"
                f"Ежедневно: {s}\n"
                f"Еженедельно: {'✅ включены' if cal.notification_weekly else '❌ выключены'}",
                reply_markup=keyboard,
                parse_mode="HTML"
            )

async def toggle_weekly(update, context):
    query = update.callback_query
    await query.answer()
    
    if not await check_access(update.effective_user.id):
        return
    async with async_session() as session:
        result = await session.execute(select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id))
        cal = result.scalars().first()
        if cal:
            cal.notification_weekly = not cal.notification_weekly
            await session.commit()
            s = "✅ включены" if cal.notification_weekly else "❌ выключены"
            
            d = "✅" if cal.notification_daily else "❌"
            w = "✅" if cal.notification_weekly else "❌"
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton(f"Ежедневно: {d}", callback_data="toggle_daily")],
                [InlineKeyboardButton(f"Еженедельно: {w}", callback_data="toggle_weekly")],
            ])
            await query.edit_message_text(
                f"🔔 <b>Настройки уведомлений:</b>\n\n"
                f"Ежедневно: {'✅ включены' if cal.notification_daily else '❌ выключены'}\n"
                f"Еженедельно: {s}",
                reply_markup=keyboard,
                parse_mode="HTML"
            )