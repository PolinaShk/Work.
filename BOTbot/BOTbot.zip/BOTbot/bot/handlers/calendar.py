from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters
from datetime import datetime, timedelta
import pytz
from sqlalchemy import select
from bot.database import async_session, User, UserCalendar
from bot.services.caldav_service import CalDAVService, test_caldav_connection
from bot.utils import encrypt_caldav_password
from bot.services.logger import send_log

CALDAV_URL, CALDAV_USERNAME, CALDAV_PASSWORD = range(3)

async def check_access(user_id):
    async with async_session() as session:
        user = await session.get(User, user_id)
        return user and user.is_approved and not user.is_blocked

async def today(update, context):
    if not await check_access(update.effective_user.id):
        await update.message.reply_text("⛔ Нет доступа.")
        return
    async with async_session() as session:
        result = await session.execute(select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id))
        cal = result.scalars().first()
        if not cal:
            await update.message.reply_text("❌ Календарь не настроен.\nИспользуйте: /addcalendar")
            return

        is_ok, error = test_caldav_connection(cal.caldav_url, cal.caldav_username, cal.caldav_password_encrypted)
        if not is_ok:
            await update.message.reply_text(f"❌ Ошибка подключения к календарю: {error}\n\nПожалуйста, добавьте календарь заново через /addcalendar")
            return

        try:
            user_tz = pytz.timezone(cal.timezone)
            now = datetime.now(user_tz)
            start_of_day = now.replace(hour=0, minute=0, second=0, microsecond=0)
            end_of_day = start_of_day + timedelta(days=1)

            service = CalDAVService(cal.caldav_url, cal.caldav_username, cal.caldav_password_encrypted)
            all_events = service.get_events(start_of_day, end_of_day)
            all_events = [e for e in all_events if not e.get("is_recurring")]
            future_events = [e for e in all_events if e["start"] > now]

            if not future_events:
                await update.message.reply_text(f"📅 На сегодня ({now.strftime('%d.%m.%Y')}) встреч больше нет.", disable_web_page_preview=True)
                return

            msg = f"📅 <b>Встречи на сегодня ({now.strftime('%d.%m.%Y')}):</b>\n\n"
            for e in sorted(future_events, key=lambda x: x["start"]):
                st = e["start"].astimezone(user_tz).strftime("%H:%M")
                et = e["end"].astimezone(user_tz).strftime("%H:%M")
                msg += f"🕐 {st} - {et}\n📌 {e['summary']}\n"
                if e["location"]:
                    msg += f"📍 {e['location']}\n"
                if e["attendees"]:
                    msg += f"👥 {', '.join(e['attendees'])}\n"
                msg += "\n"
            await update.message.reply_text(msg, parse_mode="HTML", disable_web_page_preview=True)
        except Exception as e:
            await update.message.reply_text("❌ Ошибка при получении встреч.")
            await send_log(f"❌ CalDAV ошибка для пользователя {update.effective_user.id}: {e}")

async def week(update, context):
    if not await check_access(update.effective_user.id):
        await update.message.reply_text("⛔ Нет доступа.")
        return
    async with async_session() as session:
        result = await session.execute(select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id))
        cal = result.scalars().first()
        if not cal:
            await update.message.reply_text("❌ Календарь не настроен.\nИспользуйте: /addcalendar")
            return

        is_ok, error = test_caldav_connection(cal.caldav_url, cal.caldav_username, cal.caldav_password_encrypted)
        if not is_ok:
            await update.message.reply_text(f"❌ Ошибка подключения к календарю: {error}\n\nПожалуйста, добавьте календарь заново через /addcalendar")
            return

        try:
            user_tz = pytz.timezone(cal.timezone)
            now = datetime.now(user_tz)
            start_of_today = now.replace(hour=0, minute=0, second=0, microsecond=0)
            monday = start_of_today - timedelta(days=start_of_today.weekday())
            sunday = monday + timedelta(days=7)

            service = CalDAVService(cal.caldav_url, cal.caldav_username, cal.caldav_password_encrypted)
            all_events = service.get_events(monday, sunday)
            all_events = [e for e in all_events if not e.get("is_recurring")]
            future_week_events = [e for e in all_events if e["start"] > now]

            if not future_week_events:
                await update.message.reply_text(f"📅 На этой неделе ({monday.strftime('%d.%m')} - {(sunday - timedelta(days=1)).strftime('%d.%m')}) больше нет встреч.", disable_web_page_preview=True)
                return

            msg = f"📅 <b>Все встречи на неделю ({monday.strftime('%d.%m')} - {(sunday - timedelta(days=1)).strftime('%d.%m')}):</b>\n\n"
            for e in sorted(future_week_events, key=lambda x: x["start"]):
                d = e["start"].astimezone(user_tz).strftime("%d.%m (%a)")
                st = e["start"].astimezone(user_tz).strftime("%H:%M")
                et = e["end"].astimezone(user_tz).strftime("%H:%M")
                msg += f"📆 {d}\n🕐 {st} - {et}\n📌 {e['summary']}\n"
                if e["location"]:
                    msg += f"📍 {e['location']}\n"
                if e["attendees"]:
                    msg += f"👥 {', '.join(e['attendees'])}\n"
                msg += "\n"
            await update.message.reply_text(msg, parse_mode="HTML", disable_web_page_preview=True)
        except Exception as e:
            await update.message.reply_text("❌ Ошибка при получении встреч.")
            await send_log(f"❌ CalDAV ошибка для пользователя {update.effective_user.id}: {e}")

async def add_calendar_start(update, context):
    if not await check_access(update.effective_user.id):
        await update.message.reply_text("⛔ Нет доступа.")
        return ConversationHandler.END
    await update.message.reply_text(
        "📅 <b>Добавление календаря CalDAV</b>\n\n"
        "Введите URL вашего календаря:\n"
        "Пример: https://mail.id-east.ru/SOGo/dav/username/Calendar/personal/\n\n"
        "/cancel — отмена",
        parse_mode="HTML",
        disable_web_page_preview=True
    )
    return CALDAV_URL

async def caldav_url(update, context):
    context.user_data["url"] = update.message.text
    await update.message.reply_text("👤 Введите логин:")
    return CALDAV_USERNAME

async def caldav_username(update, context):
    context.user_data["username"] = update.message.text
    await update.message.reply_text("🔑 Введите пароль:")
    return CALDAV_PASSWORD

async def caldav_password(update, context):
    encrypted = encrypt_caldav_password(update.message.text)

    url = context.user_data["url"]
    username = context.user_data["username"]
    is_ok, error = test_caldav_connection(url, username, encrypted)

    if not is_ok:
        await update.message.reply_text(f"❌ Не удалось подключиться к календарю: {error}\n\nПроверьте правильность URL, логина и пароля.")
        return ConversationHandler.END

    async with async_session() as session:
        from sqlalchemy import delete
        await session.execute(delete(UserCalendar).where(UserCalendar.user_id == update.effective_user.id))

        cal = UserCalendar(
            user_id=update.effective_user.id,
            caldav_url=url,
            caldav_username=username,
            caldav_password_encrypted=encrypted
        )
        session.add(cal)
        await session.commit()
    await update.message.delete()
    await update.message.reply_text("✅ Календарь успешно добавлен и проверен!")
    return ConversationHandler.END

async def cancel(update, context):
    await update.message.reply_text("❌ Операция отменена.")
    return ConversationHandler.END