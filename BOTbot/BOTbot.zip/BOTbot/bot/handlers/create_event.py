from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler, MessageHandler, filters, CallbackQueryHandler
from datetime import datetime, timedelta
import pytz
from sqlalchemy import select
from bot.database import async_session, User, UserCalendar
from bot.services.caldav_service import CalDAVService, send_email_invite
from bot.services.logger import send_log
import logging

logger = logging.getLogger(__name__)

EVT_SUMMARY, EVT_START, EVT_DURATION, EVT_LOCATION, EVT_ATTENDEES = range(5)
FORCE_CREATE = 99
FIND_FREE_TIME = 100

PROJECT_EMAIL = "mailbot@id-east.ru"
INCLUDE_WEEKENDS = False

async def safe_edit_message(message_obj, text, parse_mode=None, reply_markup=None, disable_web_page_preview=None):
    try:
        if hasattr(message_obj, 'edit_text'):
            await message_obj.edit_text(
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup,
                disable_web_page_preview=disable_web_page_preview
            )
        elif hasattr(message_obj, 'edit_message_text'):
            await message_obj.edit_message_text(
                text=text,
                parse_mode=parse_mode,
                reply_markup=reply_markup,
                disable_web_page_preview=disable_web_page_preview
            )
        return True
    except Exception as e:
        if "Message is not modified" not in str(e):
            raise e
        return False

async def check_access(user_id):
    async with async_session() as session:
        user = await session.get(User, user_id)
        return user and user.is_approved and not user.is_blocked

def add_required_attendees(attendees, author_email):
    """Добавляет обязательных участников: project email и автора"""
    required = set()
    required.add(PROJECT_EMAIL)
    if author_email:
        required.add(author_email)
    for attendee in attendees:
        if attendee and attendee.strip():
            required.add(attendee.strip())
    return list(required)

def send_regular_email_invites(summary, start, end, location, attendees, organizer_email):
    """Отправляет email приглашения всем участникам"""
    result = {"emailed": [], "failed": []}
    if not attendees:
        return result
    
    start_msk = start.astimezone(pytz.timezone("Europe/Moscow")) if start.tzinfo else pytz.timezone("Europe/Moscow").localize(start)
    end_msk = end.astimezone(pytz.timezone("Europe/Moscow")) if end.tzinfo else pytz.timezone("Europe/Moscow").localize(end)
    
    subject = f"Приглашение на встречу: {summary}"
    
    location_text = location if location else "не указано"
    
    body_text = f"""
Приглашение на встречу: {summary}

Дата и время: {start_msk.strftime('%d.%m.%Y %H:%M')} - {end_msk.strftime('%H:%M')}
Место: {location_text}

Организатор: {organizer_email}

---
Это приглашение создано автоматически через Telegram бота iCalendarPM.
    """
    
    body_html = f"""
<html>
<body>
<h2>Приглашение на встречу: {summary}</h2>
<p><b>Дата и время:</b> {start_msk.strftime('%d.%m.%Y %H:%M')} - {end_msk.strftime('%H:%M')}</p>
<p><b>Место:</b> {location_text}</p>
<p><b>Организатор:</b> {organizer_email}</p>
<hr>
<p><small>Это приглашение создано автоматически через Telegram бота iCalendarPM.</small></p>
</body>
</html>
    """
    
    for attendee in attendees:
        if attendee:
            if send_email_invite(attendee, subject, body_text, body_html, None):
                result["emailed"].append(attendee)
            else:
                result["failed"].append(attendee)
    
    return result

async def create_event_start(update, context):
    if not await check_access(update.effective_user.id):
        await update.message.reply_text("⛔ Нет доступа.")
        return ConversationHandler.END
    
    context.user_data.clear()
    
    await update.message.reply_text(
        "📝 <b>Создание новой встречи</b>\n\n"
        "Введите название встречи:\n\n"
        "(для отмены отправьте /cancel)",
        parse_mode="HTML",
        disable_web_page_preview=True
    )
    return EVT_SUMMARY

async def event_summary(update, context):
    context.user_data["event_summary"] = update.message.text
    await update.message.reply_text(
        "📅 Введите дату и время начала (ДД.ММ.ГГГГ ЧЧ:ММ):\n"
        "Например: 13.05.2026 14:30",
        disable_web_page_preview=True
    )
    return EVT_START

async def event_start_time(update, context):
    try:
        dt = datetime.strptime(update.message.text, "%d.%m.%Y %H:%M")
        tz = pytz.timezone("Europe/Moscow")
        context.user_data["event_start_time"] = tz.localize(dt)
        await update.message.reply_text(
            "⏱ Введите длительность в минутах (15-480):\n"
            "Например: 60",
            disable_web_page_preview=True
        )
        return EVT_DURATION
    except ValueError:
        await update.message.reply_text(
            "❌ Неверный формат. Попробуйте ещё раз:\n"
            "ДД.ММ.ГГГГ ЧЧ:ММ\n"
            "Например: 13.05.2026 14:30",
            disable_web_page_preview=True
        )
        return EVT_START

async def event_duration(update, context):
    try:
        d = int(update.message.text)
        if d < 15 or d > 480:
            raise ValueError
        context.user_data["event_duration"] = d
        await update.message.reply_text(
            "📍 Введите место встречи (или - чтобы пропустить):",
            disable_web_page_preview=True
        )
        return EVT_LOCATION
    except ValueError:
        await update.message.reply_text(
            "❌ Введите число от 15 до 480 (минут):",
            disable_web_page_preview=True
        )
        return EVT_DURATION

async def event_location(update, context):
    location = update.message.text
    context.user_data["event_location"] = location if location != "-" else ""
    await update.message.reply_text(
        "👥 Введите email участников через запятую (или - чтобы пропустить):\n"
        "Например: user1@example.com, user2@example.com\n\n"
        "📧 Приглашения будут отправлены на указанные email адреса.\n"
        disable_web_page_preview=True
    )
    return EVT_ATTENDEES

def find_all_free_slots(service, start_date, duration, max_days=14, max_slots=10):
    work_start = 9
    work_end = 18
    step_minutes = 15
    
    all_free_slots = []
    selected_day = start_date.replace(hour=0, minute=0, second=0, microsecond=0)
    
    day_offset = 0
    days_checked = 0
    
    while len(all_free_slots) < max_slots and days_checked <= max_days:
        current_day = selected_day + timedelta(days=day_offset)
        
        if not INCLUDE_WEEKENDS and current_day.weekday() >= 5:
            day_offset += 1
            continue
        
        current = current_day.replace(hour=work_start, minute=0, second=0, microsecond=0)
        day_end = current_day.replace(hour=work_end, minute=0, second=0, microsecond=0)
        
        if day_offset == 0 and start_date.hour >= work_start:
            current = start_date
            minutes = current.minute
            remainder = minutes % step_minutes
            if remainder != 0:
                current = current.replace(minute=minutes + (step_minutes - remainder), second=0, microsecond=0)
        
        while current < day_end and len(all_free_slots) < max_slots:
            slot_end = current + timedelta(minutes=duration)
            
            if slot_end > day_end:
                break
            
            try:
                events = service.get_events(current, slot_end)
                conflicts = [e for e in events if e["start"] < slot_end and e["end"] > current]
                
                if not conflicts:
                    all_free_slots.append(current)
                    current += timedelta(minutes=step_minutes)
                else:
                    conflict_end = max([e["end"] for e in conflicts])
                    current = conflict_end
                    minutes = current.minute
                    remainder = minutes % step_minutes
                    if remainder != 0:
                        current = current.replace(minute=minutes + (step_minutes - remainder), second=0, microsecond=0)
            except Exception as e:
                logger.error(f"Ошибка проверки слота: {e}")
                current += timedelta(minutes=step_minutes)
        
        day_offset += 1
        days_checked += 1
    
    return all_free_slots

async def event_attendees(update, context):
    text = update.message.text
    user_attendees = []
    if text != "-":
        user_attendees = [email.strip() for email in text.split(",") if email.strip()]
    
    context.user_data["event_attendees"] = user_attendees
    
    start = context.user_data["event_start_time"]
    duration = context.user_data["event_duration"]
    end = start + timedelta(minutes=duration)
    summary = context.user_data["event_summary"]
    location = context.user_data["event_location"]
    
    status_msg = await update.message.reply_text("🔍 Проверяю календарь на наличие конфликтов...", disable_web_page_preview=True)
    
    async with async_session() as session:
        result = await session.execute(
            select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id)
        )
        cal = result.scalars().first()
        
        if not cal:
            await safe_edit_message(status_msg, "❌ Сначала добавьте календарь: /addcalendar")
            return ConversationHandler.END
        
        try:
            service = CalDAVService(
                cal.caldav_url, 
                cal.caldav_username, 
                cal.caldav_password_encrypted
            )
            
            existing_events = service.get_events(start, end)
            conflicts = [e for e in existing_events if e["start"] < end and e["end"] > start]
            
            if conflicts:
                context.user_data["original_start_time"] = start
                
                msg = "⚠️ <b>Обнаружены конфликты:</b>\n\n"
                for e in sorted(conflicts, key=lambda x: x["start"]):
                    st = e["start"].astimezone(pytz.timezone("Europe/Moscow")).strftime("%d.%m.%Y %H:%M")
                    et = e["end"].astimezone(pytz.timezone("Europe/Moscow")).strftime("%H:%M")
                    msg += f"📌 <b>{e['summary']}</b>\n"
                    msg += f"🕐 {st} - {et}\n"
                    if e.get("location"):
                        msg += f"📍 {e['location']}\n"
                    msg += "\n"
                msg += "⏰ Что делаем?"
                
                keyboard = InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Да, создать", callback_data="force_create")],
                    [InlineKeyboardButton("🔍 Найти свободное время", callback_data="find_free_time")],
                    [InlineKeyboardButton("❌ Отмена", callback_data="cancel_create")]
                ])
                
                await safe_edit_message(status_msg, msg, parse_mode="HTML", reply_markup=keyboard, disable_web_page_preview=True)
                return FORCE_CREATE
            
            await safe_edit_message(status_msg, "⏳ Создаю встречу...", disable_web_page_preview=True)
            
            attendees = add_required_attendees(user_attendees, cal.caldav_username)
            
            description = f"Встреча создана через Telegram бота iCalendarPM\n"
            if attendees:
                description += f"\nУчастники: {', '.join(attendees)}\n"
            
            success, uid = service.create_event(
                summary=summary,
                start=start,
                end=end,
                location=location,
                attendees=attendees,
                description=description
            )
            
            if success:
                email_result = send_regular_email_invites(
                    summary=summary,
                    start=start,
                    end=end,
                    location=location,
                    attendees=attendees,
                    organizer_email=cal.caldav_username
                )
                
                msg = f"✅ <b>Встреча создана!</b>\n\n"
                msg += f"📌 <b>{summary}</b>\n"
                msg += f"🕐 {start.strftime('%d.%m.%Y %H:%M')} - {end.strftime('%H:%M')}\n"
                if location:
                    msg += f"📍 {location}\n"
                if attendees:
                    msg += f"\n👥 <b>Участники:</b>\n"
                    for att in attendees:
                        msg += f"• {att}\n"
                msg += f"\n📧 Приглашения отправлены {', '.join(email_result['emailed'])}"
                
                await safe_edit_message(status_msg, msg, parse_mode="HTML", disable_web_page_preview=True)
                await send_log(
                    f"✅ Пользователь {update.effective_user.id} создал встречу: "
                    f"{summary} на {start.strftime('%d.%m.%Y %H:%M')}, "
                    f"участников: {len(attendees)}"
                )
            else:
                await safe_edit_message(status_msg, "❌ Ошибка при создании встречи")
                
        except Exception as e:
            error_str = str(e)
            if "401" in error_str:
                await safe_edit_message(status_msg, "❌ Неверный пароль календаря. Пожалуйста, добавьте календарь заново через /addcalendar")
            elif "timeout" in error_str.lower():
                await safe_edit_message(status_msg, "❌ Таймаут подключения. Проверьте интернет-соединение или прокси.")
            else:
                await safe_edit_message(status_msg, f"❌ Ошибка: {error_str[:200]}", disable_web_page_preview=True)
            await send_log(f"❌ Ошибка создания встречи для {update.effective_user.id}: {e}")
    
    return ConversationHandler.END

async def force_create_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "cancel_create":
        await safe_edit_message(query, "❌ Создание встречи отменено.")
        return ConversationHandler.END
    
    if query.data == "find_free_time":
        await safe_edit_message(query, "🔍 Ищу свободное время...", disable_web_page_preview=True)
        return await find_free_time_handler(update, context)
    
    summary = context.user_data.get("event_summary")
    start = context.user_data.get("event_start_time")
    duration = context.user_data.get("event_duration")
    location = context.user_data.get("event_location", "")
    user_attendees = context.user_data.get("event_attendees", [])
    
    if not all([summary, start, duration]):
        await safe_edit_message(query, "❌ Данные встречи утеряны. Начните заново: /create_event")
        return ConversationHandler.END
    
    end = start + timedelta(minutes=duration)
    
    await safe_edit_message(query, "⏳ Создаю встречу (несмотря на конфликты)...", disable_web_page_preview=True)
    
    async with async_session() as session:
        result = await session.execute(
            select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id)
        )
        cal = result.scalars().first()
        
        if not cal:
            await safe_edit_message(query, "❌ Календарь не найден.")
            return ConversationHandler.END
        
        try:
            service = CalDAVService(
                cal.caldav_url, 
                cal.caldav_username, 
                cal.caldav_password_encrypted
            )
            
            attendees = add_required_attendees(user_attendees, cal.caldav_username)
            
            description = f"Встреча создана через Telegram бота iCalendarPM (создана вопреки конфликту)\n"
            if attendees:
                description += f"\nУчастники: {', '.join(attendees)}\n"
            
            success, uid = service.create_event(
                summary=summary,
                start=start,
                end=end,
                location=location,
                attendees=attendees,
                description=description
            )
            
            if success:
                email_result = send_regular_email_invites(
                    summary=summary,
                    start=start,
                    end=end,
                    location=location,
                    attendees=attendees,
                    organizer_email=cal.caldav_username
                )
                
                msg = f"✅ <b>Встреча создана!</b>\n\n"
                msg += f"📌 <b>{summary}</b>\n"
                msg += f"🕐 {start.strftime('%d.%m.%Y %H:%M')} - {end.strftime('%H:%M')}\n"
                if location:
                    msg += f"📍 {location}\n"
                if attendees:
                    msg += f"\n👥 <b>Участники:</b>\n"
                    for att in attendees:
                        msg += f"• {att}\n"
                msg += f"\n📧 Приглашения отправлены {', '.join(email_result['emailed'])}"
                msg += f"\n\n⚠️ Встреча создана, несмотря на конфликты."
                
                await safe_edit_message(query, msg, parse_mode="HTML", disable_web_page_preview=True)
                await send_log(
                    f"✅ Пользователь {update.effective_user.id} создал встречу (вопреки конфликту): "
                    f"{summary} на {start.strftime('%d.%m.%Y %H:%M')}"
                )
            else:
                await safe_edit_message(query, "❌ Ошибка при создании встречи")
                
        except Exception as e:
            error_str = str(e)
            if "401" in error_str:
                await safe_edit_message(query, "❌ Неверный пароль календаря. Пожалуйста, добавьте календарь заново через /addcalendar")
            else:
                await safe_edit_message(query, f"❌ Ошибка: {error_str[:200]}", disable_web_page_preview=True)
            await send_log(f"❌ Ошибка создания встречи для {update.effective_user.id}: {e}")
    
    return ConversationHandler.END

async def find_free_time_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    if query.data == "cancel_find_free_time":
        await safe_edit_message(query, "❌ Поиск свободного времени отменён.")
        return ConversationHandler.END
    
    summary = context.user_data.get("event_summary")
    duration = context.user_data.get("event_duration")
    location = context.user_data.get("event_location", "")
    user_attendees = context.user_data.get("event_attendees", [])
    original_start = context.user_data.get("original_start_time")
    
    if not all([summary, duration, original_start]):
        await safe_edit_message(query, "❌ Данные встречи утеряны. Начните заново: /create_event")
        return ConversationHandler.END
    
    await safe_edit_message(query, "🔍 Ищу свободное время...", disable_web_page_preview=True)
    
    async with async_session() as session:
        result = await session.execute(
            select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id)
        )
        cal = result.scalars().first()
        
        if not cal:
            await safe_edit_message(query, "❌ Календарь не найден.")
            return ConversationHandler.END
        
        try:
            service = CalDAVService(
                cal.caldav_url, 
                cal.caldav_username, 
                cal.caldav_password_encrypted
            )
            
            free_slots = find_all_free_slots(service, original_start, duration, max_days=14, max_slots=10)
            
            if not free_slots:
                await safe_edit_message(
                    query,
                    "❌ Не удалось найти свободное время в ближайшие 14 дней.\n"
                    "Попробуйте выбрать другую дату вручную.",
                    disable_web_page_preview=True
                )
                return ConversationHandler.END
            
            context.user_data["free_slots"] = {slot.timestamp(): slot for slot in free_slots}
            
            keyboard_buttons = []
            weekdays_ru = ["ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС"]
            
            for slot in free_slots[:10]:
                slot_end = slot + timedelta(minutes=duration)
                weekday = weekdays_ru[slot.weekday()]
                date_str = slot.strftime("%d.%m.%Y %H:%M")
                button_text = f"{weekday} {date_str} - {slot_end.strftime('%H:%M')}"
                keyboard_buttons.append([InlineKeyboardButton(button_text, callback_data=f"free_slot_{slot.timestamp()}")])
            
            keyboard_buttons.append([InlineKeyboardButton("❌ Отмена", callback_data="cancel_find_free_time")])
            keyboard = InlineKeyboardMarkup(keyboard_buttons)
            
            msg = f"🔍 <b>Найдено {len(free_slots)} свободных окон:</b>\n\n"
            msg += f"📌 <b>{summary}</b> ({duration} мин)\n\n"
            msg += "Выберите удобное время:"
            
            await safe_edit_message(query, msg, parse_mode="HTML", reply_markup=keyboard, disable_web_page_preview=True)
            return FIND_FREE_TIME
            
        except Exception as e:
            logger.error(f"Ошибка поиска свободного времени: {e}")
            error_str = str(e)
            if "401" in error_str:
                await safe_edit_message(query, "❌ Неверный пароль календаря. Пожалуйста, добавьте календарь заново через /addcalendar")
            else:
                await safe_edit_message(query, f"❌ Ошибка: {error_str[:200]}", disable_web_page_preview=True)
            await send_log(f"❌ Ошибка поиска свободного времени: {e}")
            return ConversationHandler.END

async def find_free_time_confirm_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    logger.info(f"find_free_time_confirm_handler called with data: {query.data}")
    
    if query.data == "cancel_find_free_time":
        await safe_edit_message(query, "❌ Создание встречи отменено.")
        return ConversationHandler.END
    
    if query.data.startswith("free_slot_"):
        try:
            timestamp = float(query.data.split("_")[2])
        except (IndexError, ValueError):
            await safe_edit_message(query, "❌ Ошибка формата данных. Попробуйте заново.")
            return ConversationHandler.END
        
        start = context.user_data.get("free_slots", {}).get(timestamp)
        
        if not start:
            await safe_edit_message(query, "❌ Выбранное время больше не доступно. Попробуйте поискать заново.")
            return ConversationHandler.END
        
        summary = context.user_data.get("event_summary")
        duration = context.user_data.get("event_duration")
        location = context.user_data.get("event_location", "")
        user_attendees = context.user_data.get("event_attendees", [])
        end = start + timedelta(minutes=duration)
        
        await safe_edit_message(query, "⏳ Создаю встречу...", disable_web_page_preview=True)
        
        async with async_session() as session:
            result = await session.execute(
                select(UserCalendar).where(UserCalendar.user_id == update.effective_user.id)
            )
            cal = result.scalars().first()
            
            if not cal:
                await safe_edit_message(query, "❌ Календарь не найден.")
                return ConversationHandler.END
            
            try:
                service = CalDAVService(
                    cal.caldav_url, 
                    cal.caldav_username, 
                    cal.caldav_password_encrypted
                )
                
                attendees = add_required_attendees(user_attendees, cal.caldav_username)
                
                description = f"Встреча создана через Telegram бота iCalendarPM\n"
                if attendees:
                    description += f"\nУчастники: {', '.join(attendees)}\n"
                
                success, uid = service.create_event(
                    summary=summary,
                    start=start,
                    end=end,
                    location=location,
                    attendees=attendees,
                    description=description
                )
                
                if success:
                    email_result = send_regular_email_invites(
                        summary=summary,
                        start=start,
                        end=end,
                        location=location,
                        attendees=attendees,
                        organizer_email=cal.caldav_username
                    )
                    
                    msg = f"✅ <b>Встреча создана!</b>\n\n"
                    msg += f"📌 <b>{summary}</b>\n"
                    msg += f"🕐 {start.strftime('%d.%m.%Y %H:%M')} - {end.strftime('%H:%M')}\n"
                    if location:
                        msg += f"📍 {location}\n"
                    if attendees:
                        msg += f"\n👥 <b>Участники:</b>\n"
                        for att in attendees:
                            msg += f"• {att}\n"
                    msg += f"\n📧 Приглашения отправлены. {', '.join(email_result['emailed'])}"
                    
                    await safe_edit_message(query, msg, parse_mode="HTML", disable_web_page_preview=True)
                    await send_log(
                        f"✅ Пользователь {update.effective_user.id} создал встречу в свободное время: "
                        f"{summary} на {start.strftime('%d.%m.%Y %H:%M')}"
                    )
                else:
                    await safe_edit_message(query, "❌ Ошибка при создании встречи")
                    
            except Exception as e:
                error_str = str(e)
                if "401" in error_str:
                    await safe_edit_message(query, "❌ Неверный пароль календаря. Пожалуйста, добавьте календарь заново через /addcalendar")
                else:
                    await safe_edit_message(query, f"❌ Ошибка: {error_str[:200]}", disable_web_page_preview=True)
                await send_log(f"❌ Ошибка создания встречи: {e}")
    
    return ConversationHandler.END

async def cancel(update, context):
    context.user_data.clear()
    await update.message.reply_text("❌ Создание встречи отменено.", disable_web_page_preview=True)
    return ConversationHandler.END